#pragma hdrstop
#pragma argsused

#include <stdio.h>

#ifdef _WIN32
#include <tchar.h>
#else
  typedef char _TCHAR;
  #define _tmain main
#endif

typedef struct
{
	char nom[15];
	char prenom[15];
	char adresse[50];
	char classe[20];

}student;

void menu(student *e, int nbrenregister,FILE *f);
void addstudent(student *e, int nbrenregister,FILE *f);
void displaystudent(student *e, int nbrenregister,FILE *f);
void savestudent(student *e, int nbrenregister,FILE *f);
void loadstudent(student *e, int nbrenregister,FILE *f);

int _tmain(int argc, _TCHAR* argv[])
{
	int nbrenregister = 0;
	student e[100];
	FILE *fichier;
	menu(e, nbrenregister,fichier);

	system("pause");
	return 0;
}

void addstudent(student *e,int nbrenregister,FILE *f)
{

	printf("Entrer le nom de l'eleve : ");
	scanf("%s",e[nbrenregister].nom);

	printf("\nEntrer le prenom de l'elve : ");
	scanf("%s", &e[nbrenregister].prenom);

	printf("\nEntrer l'adresse de l'elve : ");
	fgetc(stdin);
	fgets(e[nbrenregister].adresse, sizeof(e[nbrenregister].adresse), stdin);


	printf("\nEntrer la classe de l'elve : ");
	scanf("%s", &e[nbrenregister].classe);

	printf("nom : %s , prenom : %s , adresse : %s , classe : %s ", e[nbrenregister].nom, e[nbrenregister].prenom, e[nbrenregister].adresse, e[nbrenregister].classe);

	nbrenregister++;

	menu(e,nbrenregister,f);

}
void displaystudent(student *e,int nbrenregister,FILE *f)
{

	int i;

	for(i=0; i<nbrenregister; i++)
	{
		printf("------------------------------");
		printf("\nEleve numero : %d", i);
		printf("\nNom de l'eleve : %s",e[i].nom);
		printf("\nPrenom de l'eleve : %s",e[i].prenom);
		printf("\nAdresse de l'eleve : %s",e[i].adresse);
		printf("\nClasse de l'eleve : %s\n",e[i].classe);
        printf("------------------------------\n");

    }
	menu(e,nbrenregister,f);
}

void savestudent(student *e, int nbrenregister,FILE *f)
{

	char chemin[100];
	int i;
	int *nbr;

	nbr = &nbrenregister;
	printf("Ecrire le chemin d'acces : ");
	scanf("%s", &chemin);
	f = fopen(chemin, "r+");

	fwrite(nbr, sizeof(int),1,f);
	fwrite(e, sizeof(student),100,f);

	fclose(f);

    menu(e,nbrenregister,f);
}

void loadstudent(student *e, int nbrenregister,FILE *f)
{

   	char chemin[100];
	int i;
	int *nbr;
	nbr = &nbrenregister;
	printf("Ecrire le chemin d'acces : ");
	scanf("%s", &chemin);
	f = fopen(chemin, "r+");

	fread(nbr, sizeof(int),1,f);
	fread(e, sizeof(student),100,f);
	fclose(f);

	menu(e,nbrenregister,f);
}

void menu(student *e,int nbrenregister,FILE *f)
{

	int choixMenu;
	printf("---Menu---\n\n");
	printf("1.Ajouter un eleve!\n");
	printf("2.Voir les eleve!\n");
	printf("3.save eleve!\n");
	printf("4.load eleve!\n");
	printf("5.Quiter!\n\n\n");
	printf("\nVotre choix?\n\n");
	scanf("%d", &choixMenu);

	switch (choixMenu) /* pourquoi choixMenu ca n'esxiste que dans la fonction affichageMenu */
	{
	case 1:
		addstudent(e,nbrenregister,f);
		break;
	case 2:
		displaystudent(e,nbrenregister,f);
		break;
	case 3:
		savestudent(e,nbrenregister,f);
		break;
	case 4:
        loadstudent(e,nbrenregister,f);
		break;
	case 5:
		exit();
		break;
	default:
		printf("Vous ne ferez rien du tout!");
		break;
	}

}
